#!/bin/bash
set -ev
pip3 install --user --upgrade docutils
